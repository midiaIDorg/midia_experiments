./run.sh /bin/bash partial/run_regression_inside_docker.sh
